import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `
    <section>
      <h1>
        About section
      </h1>
      <pre>Forslag 1: Kan du skaffe data fra "/api/about" her :-) </pre>
  </section>
  `,
  styles: [`
  section{
    background-color: lightgreen;
  }
  `]
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
