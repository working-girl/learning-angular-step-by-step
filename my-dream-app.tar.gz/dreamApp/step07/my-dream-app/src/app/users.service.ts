import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';


@Injectable()
export class UsersService {

  private headers = new Headers({ 'Content-Type': 'application/json', 'charset': 'UTF-8' });
  private options = new RequestOptions({ headers: this.headers });

  constructor(private http: Http) { }

  private getDemoDataOnErrorOrOffline(){
  	 let userData = [
  	  {
  	  	name : "DemoName1" , 
  	  	title: "DemoTitle1",
  	  	tags : ["OFFLINE"]
  	  },{
        name : "DemoName2" , 
        title: "DemoTitle2",
        tags : ["OFFLINE","OFFLINE"]
      },{
        name : "DemoName3" , 
        title: "DemoTitle3",
        tags : ["OFFLINE","OFFLINE","OFFLINE"]
      }
  	];

  	return userData
  }

  online:boolean = undefined

  getUsersData(): Observable<any> {
  	const address = '/api/users'
    return this
    			.http
    			
    			.get(  address,	this.options)
    			
          // please return realData as json on success
    			.map(  res	=>{ 
                          this.online = true; 
                          return res.json() ;
                        })
    			
          // please return offlineData as array on error
    			.catch( (error:any) => { 
                                   this.online = false ; 
                                   return [this.getDemoDataOnErrorOrOffline()] ;
                                })
    			/*
    			.catch( (error:any) => {
    				
    				delete error["_body"];
    				delete error["headers"];
    				error.message = `Husk at kører npm start fra (server-app) `;
    				error.DemoData = this.getDemoData()

    				return [error]

    			})
    			*/
  }
  

}
