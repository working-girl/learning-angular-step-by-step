import { Component, OnInit } from '@angular/core';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  
  userData:any
  isOnline:boolean 

  constructor(private userService: UsersService) { }

  ngOnInit() {
      this.getUsers()
  }

  getUsers(){
    this.userService
      .getUsersData()
      .subscribe(response => {  
                                this.isOnline = this.userService.online;
                                this.userData = response 
                              })
  }


}
