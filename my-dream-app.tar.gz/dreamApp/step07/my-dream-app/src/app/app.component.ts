import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
 	 <nav>
      <ul>
        <li><a routerLink="/">Home</a></li>
        <li><a routerLink="/about">About</a></li>
        <li><a routerLink="/contact">Contact</a></li>
        <li><a routerLink="/users">Users</a></li>
      </ul>
    </nav>

  <router-outlet></router-outlet>
  `,
  styles: [ `
	nav ul {
	  list-style: none;
	  background-color: #444;
	  text-align: center;
	  padding: 0;
	  margin: 0;
	}
	nav li {
	  font-family: sans-serif;
	  font-size: 1.2em;
	  line-height: 40px;
	  height: 40px;
	  border-bottom: 1px solid #888;
	}
	 
	nav a {
	  text-decoration: none;
	  color: #fff;
	  display: block;
	  transition: .3s background-color;
	}
	 
	nav a:hover {
	  background-color: #005f5f;
	}
  
  `
  ]
})
export class AppComponent {
  title = 'app works!';
}
