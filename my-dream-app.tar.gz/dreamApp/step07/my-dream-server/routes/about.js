var express = require('express');
var router = express.Router();
var config  = require('../config');


/**
 * @api {get}  /api/about HENT /api/about 
 * @apiDescription Viser server konfiguration og package.json 
 * @apiGroup ABOUT
 */
router.get('/', function(req, res, next) {
	
  res.json(config)

});

module.exports = router;
