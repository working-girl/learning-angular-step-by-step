var express = require('express');
var router = express.Router();

let config = require('../config');

/**
 * @api {get}  /api/users HENT /api/users 
 * @apiDescription Hent alle brugere 
 * @apiGroup USERS
 */
router.get('/', function(req, res, next) {
  

  let userData = [
	  {
	  	name : "ServerAdmin" , 
	  	title: "CEO",
	  	tags : ["IT","SEO"]
	  },
	  {
	  	name : config.SERVER.author, 
	  	title: config.SERVER.description,
	  	tags : config.SERVER.keywords
	  }

  ]

  res.json(userData)

});

module.exports = router;
