var express = require('express');
var router = express.Router();
var config  = require('../config');

/* GET Server landingPage. */
router.get('/', function(req, res, next) {

  	res.render('index', {data :config});

});

module.exports = router;
