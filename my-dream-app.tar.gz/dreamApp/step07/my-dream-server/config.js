
let config = {
	// Dynamisk PORT tildeling  
	PORT    :  process.env.PORT ||  1234 , 
 
	SERVER : require('./package')
	
}

module.exports = config