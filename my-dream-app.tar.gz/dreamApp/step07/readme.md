# step07

### Build more API 

* my-dream-server (used for serverside dataServices and remoting)
* my-dream-app ( Single Page APP with latest angular framework )

1) Start with data  
2) Then Build amazing Apps
