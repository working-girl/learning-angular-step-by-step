# step01 

Using the latest version of angular Command Line Interface 


### Install angular CLI

```
npm install @angular/cli --global

```

### Verify ng help 

```
ng --help >> ngHelp.txt 

```

### Verify ng help new

```
ng help new 

```

### use ng to create new app 

```
ng new my-dream-app  --skipInstall --skipTests --routing --inlineStyle --inlineTemplate  

cd my-dream-app

npm install 

npm start

```