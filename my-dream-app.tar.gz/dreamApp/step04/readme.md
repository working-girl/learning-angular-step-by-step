# step04 

### Serverside javaScript setup 

Using [ExpressJS Generator](https://expressjs.com/en/starter/generator.html)


```
npm install express-generator --global

express --help

express my-dream-server --hbs

cd my-dream-server

npm install 

npm start

```

