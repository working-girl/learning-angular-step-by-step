# step12

Take a closer look at the products module
