# step05 


### 0) Create server-app 

```
rimraf my-dream-server

express my-dream-server --hbs --git

cd my-dream-server

npm install 


```

### 1) link from server to client

Find "/my-dream-server/views/index.hbs"

make a link to client-app:

```

<p>
   Welcome to <a href="/my-dream-app">MyDreamApp</a>
</p>

```



### 2) Building client-app into server-app

my-dream-app is the client-app (using angular)
my-dream-server is the server-app (using node)

```
cd ..\my-dream-app
npm run build:fullstack 

cd ..\my-dream-server
npm run start 

```

### 3) server/client routing 

How to fix the routing problem between the client-app and server-app

Find "/my-dream-app/src/app/app.component.ts"

Fix the code to use routerLink attribute like this: 

```html

<nav>
      <ul>
        <li><a routerLink="/">Home</a></li>
        <li><a routerLink="/about">About</a></li>
        <li><a routerLink="/contact">Contact</a></li>
      </ul>
</nav>

```


