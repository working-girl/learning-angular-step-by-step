import { BrowserModule }          from '@angular/platform-browser';
import { NgModule , 
         CUSTOM_ELEMENTS_SCHEMA}  from '@angular/core';
import { FormsModule ,
         ReactiveFormsModule}     from '@angular/forms';
import { HttpModule }             from '@angular/http';

import { AppRoutingModule }       from './app-routing.module';
import { AppComponent }           from './app.component';
import { AboutComponent }         from './about/about.component';
import { OpgaveComponent }        from './opgave/opgave.component';
import { DataServiceOpgaver }     from './opgave/opgave.service';
import { HomeComponent }          from './home/home.component' ; 
import { ToastComponent }         from './toast/toast.component';
import { CustomerComponent }      from './customers/customer.component';

/* Feature Modules */
import { ProductModule }           from './products/product.module';
import { VejretComponent }         from './vejret/vejret.component';


@NgModule({
  declarations: 
  [
    AppComponent,
    AboutComponent,
    OpgaveComponent,
    HomeComponent,
    ToastComponent,
    CustomerComponent,
    VejretComponent
  ],
  imports: 
  [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    AppRoutingModule,
    ProductModule

  ],
  providers: 
  [
    DataServiceOpgaver,
    ToastComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})

export class AppModule { }
