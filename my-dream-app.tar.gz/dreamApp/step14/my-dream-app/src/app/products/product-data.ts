import { InMemoryDbService } from 'angular-in-memory-web-api';

import { IProduct } from './product';

export class ProductData implements InMemoryDbService {


    createDb() {
        let products: IProduct[] = [
             {
                'id': '1',
                'productName': 'TypeScript/JavaScript Programmering',
                'productCode': 'SU-084',
                'releaseDate': 'March 20, 2017',
                'description': 'At give deltagere viden og færdigheder til at kunne forstå og bruge TypeScript (kompatibelt med JavaScript), som er efterfølgeren til JavaScript.',
                'price': 14000,
                'starRating': 5.0,
                'imageUrl': 'https://www.superusers.dk/images/teknologi/ikon/ikon_web_apps.png',
                
                'tags': ['software', 'programmering', 'web']
            },
            {
                'id': '2',
                'productName': 'Angular 2 Workshop',
                'productCode': 'SU-074',
                'releaseDate': 'April 20, 2017',
                'description': 'At få dybere hands on erfaring med Angular 2, samt at forstå yderligere hvordan man arbejder med data ',
                'price': 14000,
                'starRating': 4.6,
                'imageUrl': 'https://www.superusers.dk/images/teknologi/ikon/ikon_angular.png',
                
                'tags': ['Framework', 'software', 'programmering', 'data', 'deployment']
            }, {
                'id': '3',
                'productName': 'Etisk Hacker - Tænk som en hacker',
                'productCode': 'SU-410',
                'releaseDate': 'Jan 15, 2017',
                'description': 'At give viden og praktiske redskaber til at kunne teste systemer for sikkerhedshuller og til at kunne sikre sig bedst muligt.',
                'price': 15000,
                'starRating': 3.9,
                'imageUrl': 'https://www.superusers.dk/images/teknologi/ikon/ikon_it_sikkerhed.png',
                
                'tags': ['technology', 'it_sikkerhed', 'programmering', 'attack', 'defense']
            }, {
                'id': '4',
                'productName': 'PowerShell Videregående',
                'productCode': 'SU-531',
                'releaseDate': 'March 20, 2017',
                'description': 'At sætte deltageren i stand til at bruge PowerShell-værktøjer, som hjælper til automatisering af dagligdags opgaver.',
                'price': 9000,
                'starRating': 3.5,
                'imageUrl': 'https://www.superusers.dk/images/teknologi/ikon/ikon_powershell.png',
                
                'tags': [ 'software', 'programmering', 'automation']
            },
            {
                'id': '5',
                'productName': 'Artificial Intelligence – Overblik og Perspektiver',
                'productCode': 'SU-600',
                'releaseDate': 'March 20, 2017',
                'description': 'Du får en rigtig god forståelse for Kunstig Intelligens, herunder Machine Learning og Deep Learning, fokus på både teknologi og anvendelser. Store ændringer er på vej i virksomheder og organisationer, vi ser på perspektiver og konsekvenser, man skal forholde sig til.',
                'price': 5800,
                'starRating': 2.8,
                'imageUrl': 'https://www.superusers.dk/images/teknologi/ikon/ikon_kunstig_intelligens.png',
                
                'tags': ['technology', 'software', 'programmering', 'analysis', 'data']
            }
        ];
        return { products };
    }


}
