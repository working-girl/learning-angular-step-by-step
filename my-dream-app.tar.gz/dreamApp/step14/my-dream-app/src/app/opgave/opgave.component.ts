import { Component, OnInit } from '@angular/core';
import { Http } from '@angular/http';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';

import { ToastComponent } 			from '../toast/toast.component';
import { DataServiceOpgaver}  		from '../opgave/opgave.service';
import * as moment 					from 'moment';


@Component({
  selector: 'app-opgave',
  templateUrl: './opgave.component.html',
  styleUrls: ['./opgave.component.css']
})
export class OpgaveComponent implements OnInit {

  startMonth:string ="";


  opgaver = [];
  isLoading = true;

  opg = {};

  isEditing = false;
  show = false;

  addOpgaverForm: FormGroup;
  date      = new FormControl('', Validators.required);
  title     = new FormControl('', Validators.required);
  body      = new FormControl('', Validators.required);
  tag       = new FormControl('', Validators.required) ;
  status    = new FormControl('', Validators.required) ;
  user      = new FormControl('', Validators.required) ;

  constructor(private http: Http,
              private dataService: DataServiceOpgaver,
              public toast: ToastComponent,
              private formBuilder: FormBuilder) { 


  }

  ngOnInit() {

    this.startMonth = moment().format("YYYY-MM")

    this.addOpgaverForm = this.formBuilder.group({
      date   : this.date,
      title  : this.title,
      body   : this.body,
      tag    : this.tag, 
      status : this.status,
      user   : this.user
    });
  }

  opretData(){
    this.show = true ; 
  }

  hentData(){
    this.getOpgaver();
  }

  getOpgaver() {
    let yyyy:string = this.startMonth.substring(0,4)
    let mm:string   = this.startMonth.substring(5)

    this.dataService.getOpgaverYYYYMM(yyyy,mm).subscribe(
      data => {
          this.opgaver = data ;
      },
      error => console.log(error),
      () => this.isLoading = false
    );
  }



  addOpgaver() {
    this.dataService.addOpgaver(this.addOpgaverForm.value).subscribe(
      res => {
        let newWork = res.json();
        this.opgaver.push(newWork);
        this.addOpgaverForm.reset();
        this.toast.setMessage('item added successfully.', 'success');

        this.getOpgaver();

      },
      error => console.log(error)
    );
  }

  enableEditing(opg) {
    this.isEditing = true;
    this.opg = opg;
  }

  cancelEditing() {
    this.isEditing = false;
    this.opg = {};
    this.toast.setMessage('item editing cancelled.', 'warning');
    // reload the opgaver to reset the editing
    this.getOpgaver();
  }

  editOpgave(editWork) {

    console.log(editWork)

    this.dataService.editOpgave(editWork).subscribe(
      res => {
        this.isEditing = false;
        this.opg = editWork;
        this.toast.setMessage('item edited successfully.', 'success');

        this.getOpgaver();

      },
      // error => console.log(error)
      error => {
          this.toast.setMessage(error, 'warning'); 
      }

    );
  }

  deleteOpgave(opg) {
    if (window.confirm('Are you sure you want to permanently delete this item?')) {
      
      this.dataService.deleteOpgave(opg).subscribe(
        res => {
          let pos = this.opgaver.map(elem => { return elem._id; }).indexOf(opg._id);
          this.opgaver.splice(pos, 1);
          this.toast.setMessage('item deleted successfully.', 'success');

          this.getOpgaver();

        },
        error => console.log(error)
      );
    }
  }

}
