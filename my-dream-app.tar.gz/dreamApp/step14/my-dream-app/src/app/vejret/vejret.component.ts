
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'vejret-i-dk',
  template: `
  
    <img   class="vejret img-responsive"
      src="http://servlet.dmi.dk/byvejr/servlet/byvejr?by={{postnummer}}&tabel=dag3_9"  />
  
  `,
  styles: [`
    
    img.vejret {
      margin-top: 10px;
    }

  `]
})
export class VejretComponent implements OnInit {

  @Input()  postnummer: number=3400;

  constructor() { }

  ngOnInit() {
  }

}
