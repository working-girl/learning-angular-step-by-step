import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
<div class="container">

 <nav class="navbar navbar-dark bg-primary">
    <div class="nav navbar-nav">
      <a routerLink="/" class="nav-item nav-link" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}">
        <i class="fa fa-home"></i> Home
      </a>

      <a routerLink="/about" class="nav-item nav-link" routerLinkActive="active">
        <i class="fa fa-question-circle"></i> About
      </a>

      <a routerLink="/opgaver" class="nav-item nav-link" routerLinkActive="active">
        <i class="fa fa-list"></i> Opgaver
      </a>

     <a routerLink="/trainer" class="nav-item nav-link"  routerLinkActive="active" >
      <i class="fa fa-calendar"></i>  Trainer 
     </a>

      <a routerLink="/customers" class="nav-item nav-link"  routerLinkActive="active" >
      <i class="fa fa-address-book"></i>  Customers 
     </a>


     
      <a [routerLink]="['/products/']" class="nav-item nav-link" routerLinkActive="active">
        <i class="fa fa-star-half-o"></i>  Product List
      </a>
      <a [routerLink]="['/products/productEdit/0']" class="nav-item nav-link" routerLinkActive="active">
        <i class="fa fa-shopping-cart"></i>  Add Product
      </a>


 
    </div>
 </nav>
  

  <router-outlet></router-outlet>

</div>

  `,
  styles: []
})


export class AppComponent { }
