import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `
  <div class="card">
  <h4 class="card-header">About</h4>
  <div class="card-block">
    <ul>
      <li><b>Author:</b> <a href="http://jalal.hejazi.dk" target="_blank">Jalal Hejazi</a></li>
      
      <li><b>API</b> 
        <a href="/docs/swagger/" target="_blank">
           Swagger API docs  
        </a>  
      </li>


      <li>
        <b>API doc datasource</b>
        <a href="/docs/swagger/swagger.json" target="_">
          Swagger.json
        </a>
      </li>

      <li>
        <b>Package Configurations</b> 
        <a href="/api/package" target="_blank">
           package.json 
        </a>  

      </li>

      <li>
        <b>Angular Configurations</b> 
        <a href="/api/angular" target="_blank">
           angular-cli.json 
        </a>  

      </li>


      <li><b>MEAN Tools </b></li>
      <ul>
        <li><a href="http://www.mongoosejs.com" target="_blank"><b>M</b>ongoose.js</a> (<a href="https://www.mongodb.com" target="_blank">MongoDB</a>)</li>
        <li><a href="http://www.expressjs.com" target="_blank"><b>E</b>xpress.js</a></li>
        <li><a href="https://www.angular.io" target="_blank"><b>A</b>ngular</a></li>
        <li><a href="https://www.nodejs.org" target="_blank"><b>N</b>ode.js</a></li>
        <li><a href="https://cli.angular.io" target="_blank">Angular CLI</a></li>
        <li><a href="http://www.getbootstrap.com" target="_blank">Bootstrap</a></li>
        <li><a href="http://www.fontawesome.io" target="_blank">Font Awesome</a></li>
      </ul>
    </ul>
  </div>
</div>


  `,
  styles: [`
  
  `]
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
