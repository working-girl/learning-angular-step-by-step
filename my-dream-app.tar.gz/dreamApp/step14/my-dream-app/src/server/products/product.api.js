
const moment = require('moment')


let api = {
	
	/**
	 * @api {get}  /api/products/ HENT /api/products 
	 * @apiDescription Get products from remote API 
	 * @apiGroup Products
	 * 
	 * @apiSuccess {string} productName  
	 * @apiSuccess {string} productCode  
	 * @apiSuccess {string} releaseDate   
	 * @apiSuccess {string} description    
	 * @apiSuccess {string} price  
	 * @apiSuccess {number} starRating   
	 * @apiSuccess {string} tags
	 */

	hentProducts : function(req,res){
		
	    let remoteAddress = `https://service.superusers.dk/DataService/KursusOversigt/KursusGaranti?format=json`
	    
	    const unirest  = require( "unirest" )

	    let productRequest = unirest("GET", remoteAddress )
		
	    productRequest.end( (response) =>   {
	    		
	    		let kursusData 	= response.body.kursusgarantier
	    		let productData = []

	    		for (var i = 0; i < kursusData.length; i++) {
	    					
	    			productData.push(
				    			{
				    				id 				: kursusData[i].nummer ,
				    				productName 	: kursusData[i].kursus,
				    				productCode     : kursusData[i].nummer,
				    				releaseDate		: moment( kursusData[i].dato ).fromNow(),
				    				description     : `Antal dage: ${kursusData[i].varighed} adressen: ${kursusData[i].lokation}`,
				    				price			: kursusData[i].pris,
				    				starRating      : 4.0,
				    				imageUrl        : `https://www.superusers.dk/images/teknologi/ikon/ikon_${kursusData[i].teknologi.toLowerCase().replace(' ','_').replace(' ','_').replace(' ','_')}.png`,
				    				tags			: kursusData[i].teknologi
				    			}
	    			)
	    		}

	    		res.json(productData)
	    })
	
	},




	/**
	 * @api {get}  /api/product/:id HENT /api/product/:id 
	 * @apiDescription Get product by id 
	 * @apiGroup Products
	 * 
	 * @apiParam   {string} id 
	 * @apiSuccess {string} productName  
	 * @apiSuccess {string} productCode  
	 * @apiSuccess {string} releaseDate   
	 * @apiSuccess {string} description    
	 * @apiSuccess {string} price  
	 * @apiSuccess {number} starRating   
	 * @apiSuccess {string} tags
	 */

	hentProduct : function(req,res){
		const id = req.params.id  
	    const remoteAddress = `http://service.superusers.dk/DataService/Kursus/Oversigt?TeknologiPrimary=1&garanti=1&KursusNummer=${id}&format=json`
	    
	    const unirest  = require( "unirest" )

	    let productRequest = unirest("GET", remoteAddress )
		
	    productRequest.end( (response) =>   {
	    		
	    		let kursusData 	= response.body.kursusoversigt
	    		let productData = []

	    		for (var i = 0; i < kursusData.length; i++) {
	    					
	    			productData.push(
				    			{
				    				id 				: kursusData[i].kursusNummer ,
				    				productName 	: kursusData[i].kursusTitel,
				    				productCode     : kursusData[i].kursusNummer,
				    				releaseDate		: '',
				    				description     : kursusData[i].kortBeskrivelse,
				    				price			: kursusData[i].pris,
				    				starRating      : 4.0,
				    				imageUrl        : `https://www.superusers.dk/images/teknologi/ikon/ikon_${kursusData[i].teknologi.toLowerCase().replace(' ','_').replace(' ','_').replace(' ','_')}.png`,
				    				tags			: [kursusData[i].teknologi, kursusData[i].kategori]
				    			}
	    			)
	    		}

	    		res.json(productData)
	    })
	
	}









}

module.exports = api 



