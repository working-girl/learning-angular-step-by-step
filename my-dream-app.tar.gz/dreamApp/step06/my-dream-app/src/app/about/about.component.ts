import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about',
  template: `
    <section>
      <h1>
        About section
      </h1>
  
  </section>
  `,
  styles: [`
  section{
    background-color: lightgreen;
  }
  `]
})
export class AboutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
