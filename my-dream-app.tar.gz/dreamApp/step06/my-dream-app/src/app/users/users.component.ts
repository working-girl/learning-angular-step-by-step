import { Component, OnInit } from '@angular/core';
import { UsersService } from '../users.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  constructor(private service: UsersService) { }

  data 

  ngOnInit() {
  	this.data =	this.service.getUsersInfo("You need to run as fullstack app to get /api/users data !!")

  	this.service
  		.getUsersData()
  		.subscribe(
          success  => this.data = success , 
          error    => this.data = error   
      )

  }



}
