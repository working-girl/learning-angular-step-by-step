# step06 


Now we have a fullstack architecture 

* client-app (my-dream-app)
* server-app (my-dream-server)


### use npm init 

create a new package.json for automation

```
rimraf package.json

npm init -y

```


### use scripts inside package.json for automation

```json

"scripts": {
    "fullstack:build": "cd ./my-dream-app && npm run build:fullstack",
    "start" :"npm run fullstack:build && cd ./my-dream-server && npm run start"
}

```

