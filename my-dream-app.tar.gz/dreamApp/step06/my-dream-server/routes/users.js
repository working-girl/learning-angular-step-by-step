var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  // res.send('respond with a resource');

  let userData = [
	  {
	  	name : "UserName1" , 
	  	title: "UserTitle1",
	  	tags : ["DEV","DEBUG"]
	  },
	  {
	  	name : "UserName2" , 
	  	title: "UserTitle2",
	  	tags : ["DEV","DEPLOY","DEBUG","DESIGN", "DEFINE"]
	  }

  ]

  res.json(userData)

});

module.exports = router;
