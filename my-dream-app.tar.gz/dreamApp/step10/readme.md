# step10

In this branch The layout is changed. Bootstrap version 4 is used. 



## TODO: opgaver module 

Lets implement the userinterface for the api endpoint '/api/opgaver' 

Follow your instructor :-) 

```
C --> Create 
R --> Read 
U --> Upate
D --> Delete

```


