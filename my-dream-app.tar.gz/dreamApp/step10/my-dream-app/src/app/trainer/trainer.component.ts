import { Component, OnInit } from '@angular/core';
import { TrainerService } from './trainer.service';

import  { 
          I_TrainerKalender } from './trainer.model' ; 

import * as moment from 'moment';

@Component({
  selector: 'app-trainer',
  templateUrl: './trainer.view.html',
  styleUrls: ['./trainer.styles.css']

})
export class TrainerComponent implements OnInit {

  constructor(private service: TrainerService) { }

  data; 
  startDato = moment().format("YYYY");


  ngOnInit() {
  
  }

  hentData(startDato){
      this.service.getTrainerData(startDato).subscribe( response => this.data = response )
      
  }

}
