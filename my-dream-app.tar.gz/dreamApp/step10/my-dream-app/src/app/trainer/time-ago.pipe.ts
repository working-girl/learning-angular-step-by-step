import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment'


@Pipe({
  name: 'timeAgo'
})
export class TimeAgoPipe implements PipeTransform {

  
  transform(value: string, args?: any): string {
  
  		//  return   `<span class="label label-info">${value}</span>`  ;

  		let dt =  moment(value,"YYYYMMDD");	// this is the format we get from the API
  		let dt_formated = dt.format("MM-DD-YYYY") 	// for English locale (default)
  		let dt_calender = moment(dt_formated).fromNow()

  		return dt_calender ;
  }



}
