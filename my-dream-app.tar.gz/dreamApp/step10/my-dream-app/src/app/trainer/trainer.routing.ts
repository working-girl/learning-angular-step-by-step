
import { TrainerComponent} from './trainer.component';


export const TrainerRoute = [
	{path : '' , component: TrainerComponent}
];


 
