import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import  { I_TrainerKalender, networkStatus } from './trainer.model' ; 


@Injectable()
export class TrainerService {

  private headers = new Headers({ 'Content-Type': 'application/json', 'charset': 'UTF-8' });
  private options = new RequestOptions({ headers: this.headers });

  constructor(private http: Http) { }

  private getDemoDataOnErrorOrOffline(){
    
    let dummyData : I_TrainerKalender = {
      //kursus_nummer      : "SU0070",
      kursus_titel       : "TypeScript/JavaScript Programmering",
      kursus_sted        : "KBG",
      kursus_lokale      : "",
      kursus_dage        : 3,
      kursus_dato        : 20171220,
      kursus_dato_yyyy   : 2017,
      kursus_dato_mm     : 12,
      status             : networkStatus.Offline

    }

    let demoData = new Array<I_TrainerKalender>() ;
    
    for (var i = 0; i < 10; ++i) {
      demoData.push(dummyData)
    }

    return demoData
  }

  getTrainerData(startDato:string): Observable<I_TrainerKalender> {
  	
  	const address:string = `/api/trainer/${startDato}` 
    
    return this
    			.http
    			.get(  address,	this.options)
    			.map(  (res:any)	=> res.json() )
    			.catch( (error:any) =>  [this.getDemoDataOnErrorOrOffline()] )
    			
  }

}
