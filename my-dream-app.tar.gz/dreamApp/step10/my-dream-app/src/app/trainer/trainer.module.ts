import { NgModule} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router'

import { TrainerRoute } from './trainer.routing';
import { TrainerComponent } from './trainer.component';
import { TrainerService } from './trainer.service';
import { TimeAgoPipe } from './time-ago.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    RouterModule.forChild(TrainerRoute)
  ],
  declarations: [TrainerComponent, TimeAgoPipe],
  providers: [TrainerService]
})
export class TrainerModule { }
