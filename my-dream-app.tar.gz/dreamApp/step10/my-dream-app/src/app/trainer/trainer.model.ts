

export interface I_TrainerKalender {
	
	kursus_nummer?		:string
    kursus_titel		:string
    kursus_sted			:string
    kursus_lokale		:string

    kursus_dage			:number
    kursus_dato			:number
    kursus_dato_yyyy	:number
    kursus_dato_mm		:number

    status?				:networkStatus
}

export enum networkStatus {
	Offline = 0, 
	Online  = 1
}


