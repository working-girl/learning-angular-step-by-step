import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
<div class="container">

 <nav class="navbar navbar-dark bg-primary">
    <div class="nav navbar-nav">
      <a routerLink="/" class="nav-item nav-link" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}">
        <i class="fa fa-home"></i> Home
      </a>

      <a routerLink="/about" class="nav-item nav-link" routerLinkActive="active">
        <i class="fa fa-info-circle"></i> About
      </a>

      <a routerLink="/opgaver" class="nav-item nav-link" routerLinkActive="active">
        <i class="fa fa-info-circle"></i> Opgaver
      </a>

     <a routerLink="/trainer" class="nav-item nav-link"  routerLinkActive="active" >
      <i class="fa fa-info-circle"></i>  Trainer 
     </a>
    </div>
 </nav>
  

  <router-outlet></router-outlet>

</div>

  `,
  styles: [ `
	
	div {
    	margin-top: 15px;
    	margin-bottom: 10px;
	}
  
  `
  ]
})


export class AppComponent { }
