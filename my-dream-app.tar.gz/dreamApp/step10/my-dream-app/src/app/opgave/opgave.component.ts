import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-opgave',
  templateUrl: './opgave.component.html',
  styleUrls: ['./opgave.component.css']
})
export class OpgaveComponent implements OnInit {

  
  constructor() { }

  ngOnInit(){}
  getOpgaver(){}
  addOpgaver(){}
  editOpgave(){}
  deleteOpgave(){}

}
