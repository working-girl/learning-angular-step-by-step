import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

@Injectable()
export class DataServiceOpgaver {

  private headers = new Headers({ 'Content-Type': 'application/json', 'charset': 'UTF-8' });
  private options = new RequestOptions({ headers: this.headers });

  constructor(private http: Http) { }

  getOpgaver(): Observable<any> {
    return this.http.get('/api/opgaver').map(res => res.json());
  }

  getOpgaverYYYYMM(yyyy:string,mm:string): Observable<any> {
    return this.http.get(`/api/opgaver/${yyyy}/${mm}`).map(res => res.json());
  }

  addOpgaver(work): Observable<any> {
    return this.http.post('/api/opgaver', JSON.stringify(work), this.options);
  }

  editOpgave(work): Observable<any> {
    return this.http.put(`/api/opgave/${work._id}`, JSON.stringify(work), this.options);
  }

  deleteOpgave(work): Observable<any> {
    return this.http.delete(`/api/opgave/${work._id}`, this.options);
  }

}
