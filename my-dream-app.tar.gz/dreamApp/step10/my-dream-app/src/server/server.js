let express = require('express');
let path = require('path');
let morgan = require('morgan'); 
let bodyParser = require('body-parser');

let mongoose = require('mongoose');
let db = mongoose.connection;

let config    = require('./config')

let app = express();


const connectionString = config.mongodb
const PORT  = config.PORT


app.set('port',  PORT );

app.use('/', express.static(__dirname + '/../../dist'));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

app.use(morgan('dev'));




let API_trainer      = require('./trainer/trainer.api');

app.get('/api/trainer/:startDato',        API_trainer.hentKalender);





///////////////////////////////////////////////////////////////////////

mongoose.connect(connectionString);

mongoose.Promise = global.Promise;

db.on('error', console.error.bind(console, 'connection error:'));

db.once('open', function() {

  let API_opgaver      = require('./opgaver/opgaver.api');

  app.get('/api/opgaver',                   API_opgaver.getOpgaver);
  app.get('/api/opgaver/:year/:month',      API_opgaver.getOpgaverYYYYMM);
  app.get('/api/opgaver/user/:username'  ,  API_opgaver.getOpgaverUser);
  app.post('/api/opgaver',                  API_opgaver.postOpgaver);
  app.put('/api/opgave/:id',                API_opgaver.updateOpgaver);
  app.delete('/api/opgave/:id',             API_opgaver.deleteOpgaver);

  // all other routes are handled by Angular
  app.get('/*', function(req, res) {
    res.sendFile(path.join(__dirname,'/../../dist/index.html'));
  })


app.listen( PORT , () => console.log(`listening on http://localhost:${PORT} + ${connectionString}` ) )


})
///////////////////////////////////////////////////////////////////////


module.exports = app;