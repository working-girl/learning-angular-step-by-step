var mongoose = require('mongoose');

var opgaverSchema = mongoose.Schema({
    date: 		String,
    title: 		String,
    body:       String,
    tag: 		String,
    status:     String,
    user:       String 
});

var OpgaverModel = mongoose.model('Opgaver', opgaverSchema);

module.exports = OpgaverModel;