
let Opgaver = require('./opgaver.model');

let api = {

	/**
	 *
	 * @apiDefine OpgaverSuccess
	 * @apiSuccess {string} date   format yyyy-mm-dd
	 * @apiSuccess {string} title  opgave titlen
	 * @apiSuccess {string} body   opgavebeskrivelse
	 * @apiSuccess {string} tag    kategori
	 * @apiSuccess {string} status  status:done, status:progress
	 * @apiSuccess {string} user   brugernavn
	 */





	/**
	 * @api {get}  /api/opgaver HENT /api/opgaver 
	 * @apiDescription Hent alle opgaver 
	 * @apiGroup Opgaver
	 * 
	 * @apiUse OpgaverSuccess
	 */
	getOpgaver : function(req,res){
		Opgaver.find({}, function(err, docs) {
	      if(err) return console.error(err);
	      res.json(docs);
	    })
	},


	/**
	 * @api {get}  /api/opgaver/:yyyy/:mm HENT /api/opgaver/:yyyy/:mm 
	 * @apiDescription Hent opgaver pr. År og Måned 
	 * @apiGroup Opgaver
	 * 
	 * @apiParam {string} yyyy YEAR 2017 
	 * @apiParam {string} mm Mounth 08 
	 * @apiUse OpgaverSuccess
	 */
	getOpgaverYYYYMM : function(req,res){
		
		let yyyy = req.params.year ;
	    let mm   = req.params.month ; 
	 
	    let query =  {date : 
	                    { 
	                      $gte : `${yyyy}-${mm}`,
	                      $lt  : `${yyyy}-${mm+1}`
	                    }
	                 }

	    Opgaver.find(query ,function(err, data) {
	      if(err) return console.error(err);

	      res.json(data);	
	      
	    })

	},


	/**
	 * @api {get}  /api/opgaver/user/:username HENT /api/opgaver/user/:username 
	 * @apiDescription Hent opgaver pr. User 
	 * @apiGroup Opgaver
	 * 
	 * @apiParam {string} username bruger 
	 * @apiUse OpgaverSuccess
	 */
	getOpgaverUser : function(req,res){
		
		
	    let query =  { user : req.params.username }

	    console.log(query)

	    Opgaver.find(query ,function(err, data) {
	      if(err) return console.error(err);

	      res.json(data);	
	      
	    })

	},


	/**
	 * @api {post}  /api/opgaver/ POST /api/opgaver/ 
	 * @apiDescription Opret opgaven  
	 * @apiGroup Opgaver
	 * 
	 * @apiParam {string} date  
	 * @apiParam {string} title  opgave titlen
	 * @apiParam {string} body  opgavebeskrivelse
	 * @apiParam {string} tag 
	 * @apiParam {string} status  status:done, status:progress
	 * @apiParam {string} user  
	 * @apiUse OpgaverSuccess
	 */
	postOpgaver : function(req, res) {
	    let obj = new Opgaver(req.body);
	    
	    obj.save(function(err, data) {
	      if(err) return console.error(err);
	      res.status(200).json(data);
	    })

	},



	/**
	 * @api {put}  /api/opgave/:id PUT /api/opgave/ 
	 * @apiDescription Opdater opgaven med id
	 * @apiGroup Opgaver
	 * 
	 * @apiParam {string} id
	 * @apiParam {string} date  
	 * @apiParam {string} title  opgave titlen
	 * @apiParam {string} body  opgavebeskrivelse
	 * @apiParam {string} tag 
	 * @apiParam {string} status  status:done, status:progress
	 * @apiParam {string} user  
	 * @apiUse OpgaverSuccess
	 */
	updateOpgaver : function(req, res) {

	    delete req.body._id ; 

	    Opgaver.findOneAndUpdate({_id: req.params.id}, req.body, function(err) {
	      if(err) return console.error(err);
	      res.sendStatus(200)
	    })
  	},



  	/**
	 * @api {delete}  /api/opgave/:id DELETE /api/opgave/:id
	 * @apiDescription slet opgaven med id 
	 * @apiGroup Opgaver
	 * @apiParam {number} id  Opgave unique ID
	 * @apiUse OpgaverSuccess
	 * 
	 */
  	deleteOpgaver : function(req, res) {
	    Opgaver.findOneAndRemove({_id: req.params.id}, function(err) {
	      if(err) return console.error(err);
	      res.sendStatus(200);
	    })
  	}





}

module.exports = api 