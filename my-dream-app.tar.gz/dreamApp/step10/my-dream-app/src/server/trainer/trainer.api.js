

let api = {
	
	/**
	 * @api {get}  /api/trainer/:startDato HENT /api/trainer/:startDato 
	 * @apiDescription Hent instruktør kalenderen udefra startDato 
	 * @apiGroup Trainer
	 * 
	 * @apiParam {string} startDato ['YYYY' , 'YYYYMM' ] 
	 * @apiSuccess {string} kursus_titel  kursus titlen 
	 * @apiSuccess {string} kursus_sted  adressen
	 * @apiSuccess {string} kursus_lokale  lokalet 
	 * @apiSuccess {string} kursus_dage  antal dage  
	 * @apiSuccess {string} kursus_dato  YYYYMMDD
	 * @apiSuccess {string} kursus_dato_yyyy   YYYY
	 * @apiSuccess {string} kursus_dato_mm   MM
	 */

	hentKalender : function(req,res){
		
		let kalenderStartDato =  req.params.startDato ||  `2017`
	    let instruktør = `JH`
	    let remoteAddress = `http://service.superusers.dk/dataservice/kalender/${instruktør}?kursus_dato=${kalenderStartDato}&format=json`
	    
	    const unirest  = require( "unirest" )

	    let kalenderRequest = unirest("GET", remoteAddress )
	        
	        kalenderRequest.end( (response) =>  res.json( response.body.KalenderList ))
	
	}

}

module.exports = api 